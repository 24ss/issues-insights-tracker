<script lang="ts">
  import { onMount } from "svelte";

  let ApexChart: any = null;
  let data = [];
  let categories: string[] = [];
  let counts: number[] = [];
  let series = [];
  let options: any = {};

  onMount(async () => {
    // ✅ Load ApexChart only in the browser
    const module = await import("svelte-apexcharts");
    ApexChart = module.default;

    const token = localStorage.getItem("token");
    const res = await fetch("http://localhost:8000/api/dashboard/severity-counts", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    data = await res.json();
    categories = data.map((d) => d.severity);
    counts = data.map((d) => d.count);

    options = {
      chart: { type: "bar" },
      title: { text: "Open Issues by Severity" },
      xaxis: { categories },
      colors: ["#2563eb"],
    };

    series = [{ name: "Issues", data: counts }];
  });
</script>

<div class="max-w-4xl mx-auto mt-6">
  <h1 class="text-2xl font-bold mb-4">Dashboard</h1>

  {#if ApexChart && series.length > 0}
    <ApexChart type="bar" {options} {series} height={350} />
  {:else}
    <p class="text-gray-500">Loading chart...</p>
  {/if}
</div>
