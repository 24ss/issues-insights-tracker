<script lang="ts">
  import "../app.css";
  import { onMount } from "svelte";
  import { goto } from "$app/navigation";
  let isAuthenticated = false;

  onMount(() => {
    const token = localStorage.getItem("token");
    isAuthenticated = !!token;
  });

  function logout() {
    localStorage.removeItem("token");
    goto("/");
  }
</script>

{#if isAuthenticated}
  <div class="min-h-screen flex bg-gray-100">
    <!-- Sidebar -->
    <aside class="w-64 bg-white shadow-lg hidden md:block">
      <div class="p-4 font-bold text-xl border-b">Tracker</div>
      <nav class="p-4 space-y-2 text-sm">
        <a href="/dashboard" class="block text-gray-700 hover:text-blue-600">Dashboard</a>
        <a href="/issues" class="block text-gray-700 hover:text-blue-600">Issues</a>
        <a href="/submit" class="block text-gray-700 hover:text-blue-600">Submit New</a>
      </nav>
    </aside>

    <!-- Main Content -->
    <main class="flex-1">
      <header class="flex items-center justify-between bg-white shadow px-6 py-4">
        <h1 class="text-xl font-semibold">Issues & Insights</h1>
        <button on:click={logout} class="text-sm bg-gray-200 px-4 py-1 rounded hover:bg-gray-300">
          Logout
        </button>
      </header>
      <div class="p-6">
        <slot />
      </div>
    </main>
  </div>
{:else}
  <slot />
{/if}
