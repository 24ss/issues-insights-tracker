<script lang="ts">
	import { goto } from '$app/navigation';
	import { onMount } from 'svelte';

	let title = '';
	let description = '';
	let file: File | null = null;
	let error = '';
	let success = '';

	const submitIssue = async () => {
		error = '';
		success = '';

		const token = localStorage.getItem('token');
		if (!token) {
			error = 'Not logged in.';
			return;
		}

		const formData = new FormData();
		formData.append('title', title);
		formData.append('description', description);
		if (file) formData.append('file', file);

		try {
			const res = await fetch('http://localhost:8000/api/issues/', {
				method: 'POST',
				headers: {
					Authorization: `Bearer ${token}`
				},
				body: formData
			});

			if (res.ok) {
				success = 'Issue submitted successfully!';
				setTimeout(() => goto('/issues'), 1000);
			} else {
				const result = await res.json();
				error = result.detail || 'Submission failed.';
			}
		} catch (err) {
			error = 'Server error.';
		}
	};
</script>

<div class="max-w-2xl mx-auto mt-12 p-6 bg-white rounded shadow">
	<h1 class="text-2xl font-bold mb-4">Submit New Issue</h1>

	{#if error}
		<div class="mb-4 text-red-600 font-semibold">{error}</div>
	{/if}

	{#if success}
		<div class="mb-4 text-green-600 font-semibold">{success}</div>
	{/if}

	<form on:submit|preventDefault={submitIssue} class="space-y-4">
		<div>
			<label class="block font-semibold">Title</label>
			<input type="text" bind:value={title} class="w-full border rounded px-3 py-2" required />
		</div>

		<div>
			<label class="block font-semibold">Description</label>
			<textarea bind:value={description} class="w-full border rounded px-3 py-2" rows="4" required />
		</div>

		<div>
			<label class="block font-semibold">Upload File (optional)</label>
			<input type="file" on:change={(e) => file = e.target.files?.[0] || null} />
		</div>

		<button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
			Submit Issue
		</button>
	</form>
</div>
